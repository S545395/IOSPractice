import UIKit

var greeting = "Hello, playground"

// comma acts as space in the outout
print("hi", 10, 12.25)

//String Interpolation
// \(variable name)
var name = "Ajay"
var grade = 89.92

print("Hello, \(name)! your grade is \(grade)")

var proLan = "Swift";

print("My favorite programming language is \(proLan)")

var age = 23
print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")

print("""
Hello
World!
""")

print ("Hello All,\rWelcome to Swift programming")

print("The list of patterns are ", terminator: "--")
print(1,2,3,4,5,6)

print("The new pattern is", terminator: "--")
print(1,2,3,4,5,6,separator: "$")


//worksheet 2 on constants and variables

var mobileBrand = "Apple";
mobileBrand = "Samasung";
print(mobileBrand)

let pi = 3.14
//pi =4.15 Error while reassigning value to constant and printed message below
print("Cannot assign to value: 'pi' is a 'let' constant")
print(pi)

var ageFromSheet2 : Int = 23
ageFromSheet2 = ageFromSheet2 * 2
print(ageFromSheet2)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)

print(10,20,30)
print(12.5,15.5)

//worksheet 3 on tuples

var httpError  = (errorCode : 404  , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )


var nameForSheet3 = ("John","Smith")
var fName = nameForSheet3.0
var lName = nameForSheet3.1
print(fName , terminator : ",")
print(lName)


let city 
